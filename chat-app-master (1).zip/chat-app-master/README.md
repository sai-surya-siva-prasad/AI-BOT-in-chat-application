# chat-app
Build a Chat App with NEW ChatGPT API | Full stack, React, Redux Toolkit, Node, OpenAI

Video: https://www.youtube.com/watch?v=ffEDkqfIzxM

For all related questions and discussions about this project, check out the discord: https://discord.gg/2FfPeEk2mX

